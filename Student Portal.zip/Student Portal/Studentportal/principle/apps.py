from django.apps import AppConfig


class PrincipleConfig(AppConfig):
    name = 'principle'
